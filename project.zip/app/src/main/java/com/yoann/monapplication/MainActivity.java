package com.yoann.monapplication;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.CookieManager;
import android.webkit.MimeTypeMap;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.InputStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_FILE_CHOOSER = 1001;
    private static final int REQUEST_LOCATION = 1002;
    private static final int REQUEST_MEDIA = 1003;
    private static final int REQUEST_NOTIFICATIONS = 1004;

    private static final boolean ENABLE_LOCATION = true;
    private static final boolean ENABLE_CAMERA = true;
    private static final boolean ENABLE_MICROPHONE = true;
    private static final boolean OPEN_EXTERNAL_LINKS = true;

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private boolean fileChooserAllowsMultiple = false;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private PermissionRequest pendingMediaRequest;

    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String LOCAL_PREFIX =
            "/v" + BuildConfig.VERSION_CODE + "/assets/www/";
    private boolean isLocalAppUri(Uri uri) { return uri != null && "https".equalsIgnoreCase(uri.getScheme()) && LOCAL_HOST.equalsIgnoreCase(uri.getHost()) && uri.getPath() != null && uri.getPath().startsWith(LOCAL_PREFIX); }
    private String localAssetPath(Uri uri) { try { String path = URLDecoder.decode(uri.getPath().substring(LOCAL_PREFIX.length()), "UTF-8"); if (path.contains("..") || path.startsWith("/")) return null; return "www/" + path; } catch (Exception error) { return null; } }
    private String mimeTypeFor(String path) { String extension = MimeTypeMap.getFileExtensionFromUrl(path); if (extension == null) extension = ""; String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase(Locale.ROOT)); if (mime != null) return mime; if (path.endsWith(".webmanifest")) return "application/manifest+json"; if (path.endsWith(".mjs")) return "text/javascript"; if (path.endsWith(".wasm")) return "application/wasm"; if (path.endsWith(".json")) return "application/json"; return "application/octet-stream"; }
    private WebResourceResponse localAssetResponse(Uri uri) { String path = localAssetPath(uri); if (path == null) return null; try { InputStream stream = getAssets().open(path); String mime = mimeTypeFor(path); String encoding = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("xml") ? "UTF-8" : null; return new WebResourceResponse(mime, encoding, stream); } catch (Exception error) { return null; } }

    @SuppressLint({"SetJavaScriptEnabled", "AllowFileAccessFromFileURLs"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        
        getWindow().setStatusBarColor(Color.parseColor("#FF7A1A"));
        getWindow().setNavigationBarColor(Color.parseColor("#11141B"));

        webView = new WebView(this);
        setContentView(webView);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        SharedPreferences runtimePrefs=getSharedPreferences(
                "forgeapk_runtime",
                MODE_PRIVATE
        );
        String assetVersion=String.valueOf(BuildConfig.VERSION_CODE);
        String previousVersion=runtimePrefs.getString(
                "web_asset_version",
                ""
        );

        if (!assetVersion.equals(previousVersion)) {
            webView.clearCache(true);
            webView.clearHistory();
            WebStorage.getInstance().deleteAllData();
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();

            runtimePrefs.edit()
                    .putString("web_asset_version",assetVersion)
                    .apply();
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setSaveFormData(false);
        if (android.os.Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) { Uri uri=request.getUrl(); if (isLocalAppUri(uri)) return localAssetResponse(uri); return super.shouldInterceptRequest(view,request); }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) { Uri uri=Uri.parse(url); if (isLocalAppUri(uri)) return localAssetResponse(uri); return super.shouldInterceptRequest(view,url); }
            private boolean handleUri(Uri uri) {
                if (uri == null) return false;
                if (isLocalAppUri(uri)) return false;
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
                if ("about".equals(scheme) || "data".equals(scheme) || "blob".equals(scheme)) return false;
                if (("http".equals(scheme) || "https".equals(scheme)) && !OPEN_EXTERNAL_LINKS) { Toast.makeText(MainActivity.this, "Navigation externe bloquée", Toast.LENGTH_SHORT).show(); return true; }
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); return true; } catch (Exception error) { Toast.makeText(MainActivity.this, "Impossible d’ouvrir ce lien", Toast.LENGTH_SHORT).show(); return true; }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUri(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUri(Uri.parse(url));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params
            ) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                fileChooserAllowsMultiple = params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] rawTypes = params == null ? new String[0] : params.getAcceptTypes();
                    List<String> accepted = new ArrayList<>();
                    for (String type : rawTypes) { if (type != null && !type.trim().isEmpty() && !accepted.contains(type.trim())) accepted.add(type.trim()); }
                    if (accepted.isEmpty()) intent.setType("*/*");
                    else if (accepted.size() == 1) intent.setType(accepted.get(0));
                    else { intent.setType("*/*"); intent.putExtra(Intent.EXTRA_MIME_TYPES, accepted.toArray(new String[0])); }
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserAllowsMultiple);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(Intent.createChooser(intent, fileChooserAllowsMultiple ? "Sélectionner plusieurs fichiers" : "Sélectionner un fichier"), REQUEST_FILE_CHOOSER);
                    return true;
                } catch (Exception error) {
                    fileChooserCallback = null; fileChooserAllowsMultiple = false;
                    Toast.makeText(MainActivity.this, "Sélecteur de fichiers indisponible", Toast.LENGTH_LONG).show();
                    return false;
                }
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback
            ) {
                if (!ENABLE_LOCATION) {
                    callback.invoke(origin, false, false);
                    return;
                }
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                    return;
                }
                pendingGeoOrigin = origin;
                pendingGeoCallback = callback;
                requestPermissions(
                        new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        },
                        REQUEST_LOCATION
                );
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                handleMediaPermissionRequest(request);
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(
                    String url,
                    String userAgent,
                    String contentDisposition,
                    String mimeType,
                    long contentLength
            ) {
                try {
                    if (url.startsWith("blob:") || url.startsWith("data:")) {
                        Toast.makeText(
                                MainActivity.this,
                                "Ce téléchargement doit être exporté par une fonction compatible Android.",
                                Toast.LENGTH_LONG
                        ).show();
                        return;
                    }
                    DownloadManager.Request download =
                            new DownloadManager.Request(Uri.parse(url));
                    String filename =
                            URLUtil.guessFileName(url, contentDisposition, mimeType);
                    download.setTitle(filename);
                    download.setDescription("Téléchargement depuis Mon application");
                    download.setMimeType(mimeType);
                    if (userAgent != null) {
                        download.addRequestHeader("User-Agent", userAgent);
                    }
                    download.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    );
                    download.setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS,
                            filename
                    );
                    DownloadManager manager =
                            (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    if (manager != null) manager.enqueue(download);
                } catch (Exception error) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) {
                        Toast.makeText(
                                MainActivity.this,
                                "Téléchargement impossible",
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                }
            }
        });

        webView.addJavascriptInterface(new NativeBridge(this), "AndroidApp");
        webView.loadUrl(
                "https://appassets.androidplatform.net" +
                LOCAL_PREFIX +
                "index.html"
        );
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED;
    }

    private void handleMediaPermissionRequest(PermissionRequest request) {
        List<String> missing = new ArrayList<>();

        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && ENABLE_CAMERA
                    && checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.CAMERA);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && ENABLE_MICROPHONE
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                missing.add(Manifest.permission.RECORD_AUDIO);
            }
        }

        if (!missing.isEmpty()) {
            pendingMediaRequest = request;
            requestPermissions(missing.toArray(new String[0]), REQUEST_MEDIA);
        } else {
            grantAllowedMedia(request);
        }
    }

    private void grantAllowedMedia(PermissionRequest request) {
        List<String> allowed = new ArrayList<>();

        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                    && ENABLE_CAMERA
                    && checkSelfPermission(Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED) {
                allowed.add(resource);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                    && ENABLE_MICROPHONE
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                allowed.add(resource);
            }
        }

        if (allowed.isEmpty()) {
            request.deny();
        } else {
            request.grant(allowed.toArray(new String[0]));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_FILE_CHOOSER && fileChooserCallback != null) {
            List<Uri> selected = new ArrayList<>();
            if (resultCode == Activity.RESULT_OK && data != null) {
                ClipData clipData = data.getClipData();
                if (clipData != null) { for (int index = 0; index < clipData.getItemCount(); index++) { Uri uri = clipData.getItemAt(index).getUri(); if (uri != null && !selected.contains(uri)) selected.add(uri); } }
                Uri single = data.getData(); if (single != null && !selected.contains(single)) selected.add(single);
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                for (Uri uri : selected) { try { getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {} }
            }
            if (!fileChooserAllowsMultiple && selected.size() > 1) selected = new ArrayList<>(selected.subList(0,1));
            fileChooserCallback.onReceiveValue(selected.isEmpty() ? null : selected.toArray(new Uri[0]));
            fileChooserCallback = null; fileChooserAllowsMultiple = false;
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_LOCATION && pendingGeoCallback != null) {
            pendingGeoCallback.invoke(
                    pendingGeoOrigin,
                    hasLocationPermission(),
                    false
            );
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }

        if (requestCode == REQUEST_MEDIA && pendingMediaRequest != null) {
            grantAllowedMedia(pendingMediaRequest);
            pendingMediaRequest = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidApp");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    public static final class NativeBridge {
        private final Activity activity;

        NativeBridge(Activity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public void showToast(final String message) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void share(final String text) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TEXT, text);
                    activity.startActivity(Intent.createChooser(intent, "Partager"));
                }
            });
        }

        @JavascriptInterface
        public void copyText(final String text) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager clipboard =
                            (ClipboardManager) activity.getSystemService(
                                    Context.CLIPBOARD_SERVICE
                            );
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(
                                ClipData.newPlainText("Texte", text)
                        );
                    }
                    Toast.makeText(activity, "Copié", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void vibrate(long milliseconds) {
            Vibrator vibrator =
                    (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null) return;

            long duration = Math.max(1L, Math.min(milliseconds, 2000L));
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(
                        VibrationEffect.createOneShot(
                                duration,
                                VibrationEffect.DEFAULT_AMPLITUDE
                        )
                );
            } else {
                vibrator.vibrate(duration);
            }
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        activity.startActivity(
                                new Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        );
                    } catch (Exception ignored) {
                    }
                }
            });
        }


        private void sendBackgroundIntent(
                String action,
                String title,
                String message,
                boolean success
        ) {
            Intent intent = new Intent(activity, BuildForegroundService.class);
            intent.setAction(action);
            intent.putExtra(BuildForegroundService.EXTRA_TITLE, title);
            intent.putExtra(BuildForegroundService.EXTRA_MESSAGE, message);
            intent.putExtra(BuildForegroundService.EXTRA_SUCCESS, success);

            if (android.os.Build.VERSION.SDK_INT >= 26) {
                activity.startForegroundService(intent);
            } else {
                activity.startService(intent);
            }
        }

        @JavascriptInterface
        public void startBackgroundTask(final String title, final String message) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (android.os.Build.VERSION.SDK_INT >= 33 &&
                            activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                                    != PackageManager.PERMISSION_GRANTED) {
                        activity.requestPermissions(
                                new String[]{Manifest.permission.POST_NOTIFICATIONS},
                                REQUEST_NOTIFICATIONS
                        );
                    }
                    sendBackgroundIntent(
                            BuildForegroundService.ACTION_START,
                            title,
                            message,
                            true
                    );
                }
            });
        }

        @JavascriptInterface
        public void updateBackgroundTask(final String message) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    sendBackgroundIntent(
                            BuildForegroundService.ACTION_UPDATE,
                            "Génération APK en cours",
                            message,
                            true
                    );
                }
            });
        }

        @JavascriptInterface
        public void finishBackgroundTask(final String message, final boolean success) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    sendBackgroundIntent(
                            BuildForegroundService.ACTION_FINISH,
                            success ? "APK prêt" : "Génération interrompue",
                            message,
                            success
                    );
                }
            });
        }

        @JavascriptInterface
        public boolean supportsBackgroundTask() {
            return true;
        }

        @JavascriptInterface
        public String getPackageName() {
            return activity.getPackageName();
        }
    }
}
