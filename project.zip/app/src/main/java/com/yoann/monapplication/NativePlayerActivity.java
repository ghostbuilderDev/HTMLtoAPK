package com.yoann.monapplication;

import android.app.PictureInPictureParams;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.mediarouter.app.MediaRouteButton;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NativePlayerActivity extends android.app.Activity {
    private ExoPlayer player;
    private PlayerView playerView;
    private String url;
    private String title;
    private String mimeType;
    private String contentType;
    private String poster;
    private String lastDiagnostic = "";
    private CastContext castContext;
    private MediaRouteButton castButton;

    private final SessionManagerListener<CastSession> castListener = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarted(CastSession session, String id) { loadRemote(session); }
        @Override public void onSessionResumed(CastSession session, boolean wasSuspended) { loadRemote(session); }
        @Override public void onSessionStarting(CastSession session) {}
        @Override public void onSessionStartFailed(CastSession session, int error) { report("CAST_START_FAILED_" + error, null); }
        @Override public void onSessionEnding(CastSession session) {}
        @Override public void onSessionEnded(CastSession session, int error) {}
        @Override public void onSessionResuming(CastSession session, String id) {}
        @Override public void onSessionResumeFailed(CastSession session, int error) { report("CAST_RESUME_FAILED_" + error, null); }
        @Override public void onSessionSuspended(CastSession session, int reason) {}
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        url = getIntent().getStringExtra("url");
        title = value(getIntent().getStringExtra("title"), "Lecture");
        mimeType = value(getIntent().getStringExtra("mimeType"), inferMime(url));
        contentType = value(getIntent().getStringExtra("contentType"), "video");
        poster = value(getIntent().getStringExtra("poster"), "");
        if (url == null || url.trim().isEmpty()) { finish(); return; }
        buildUi();
        initCast();
        initPlayer();
        if (getIntent().getBooleanExtra("openCast", false)) castButton.performClick();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        root.addView(playerView, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(16,16,16,16);
        top.setBackgroundColor(0x66000000);
        Button back = new Button(this); back.setText("‹"); back.setOnClickListener(v -> finish());
        TextView text = new TextView(this); text.setText(title); text.setTextColor(0xFFFFFFFF); text.setTextSize(17); text.setPadding(12,0,12,0);
        top.addView(back,new LinearLayout.LayoutParams(56,56));
        top.addView(text,new LinearLayout.LayoutParams(0,56,1));
        castButton = new MediaRouteButton(this);
        top.addView(castButton,new LinearLayout.LayoutParams(56,56));
        Button diag = new Button(this); diag.setText("Diag"); diag.setOnClickListener(v -> saveDiagnostic(lastDiagnostic.isEmpty() ? buildDiagnostic("MANUAL",null) : lastDiagnostic));
        top.addView(diag,new LinearLayout.LayoutParams(82,56));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1,-2,Gravity.TOP);
        root.addView(top,tp);
        setContentView(root);
    }

    private void initCast() {
        try {
            castContext = CastContext.getSharedInstance(this);
            CastButtonFactory.setUpMediaRouteButton(getApplicationContext(), castButton);
            castContext.getSessionManager().addSessionManagerListener(castListener, CastSession.class);
        } catch (Throwable error) {
            castButton.setVisibility(View.GONE);
            report("CAST_INIT_FAILED", error);
        }
    }

    private void initPlayer() {
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(20000)
                .setReadTimeoutMs(30000)
                .setUserAgent("VLC/3.0.21 LibVLC/3.0.21");
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(http))
                .build();
        playerView.setPlayer(player);
        MediaItem.Builder item = new MediaItem.Builder().setUri(url)
                .setMediaMetadata(new MediaMetadata.Builder().setTitle(title).build());
        String inferred = inferMime(url);
        if (inferred != null) item.setMimeType(inferred);
        player.setMediaItem(item.build());
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException error) {
                report("PLAYER_ERROR_" + error.errorCodeName, error);
            }
        });
        player.prepare();
        player.play();
    }

    private void loadRemote(CastSession session) {
        try {
            RemoteMediaClient client = session.getRemoteMediaClient();
            if (client == null) throw new IllegalStateException("RemoteMediaClient absent");
            com.google.android.gms.cast.MediaMetadata md = new com.google.android.gms.cast.MediaMetadata(com.google.android.gms.cast.MediaMetadata.MEDIA_TYPE_MOVIE);
            md.putString(com.google.android.gms.cast.MediaMetadata.KEY_TITLE, title);
            if (!poster.isEmpty()) md.addImage(new com.google.android.gms.common.images.WebImage(Uri.parse(poster)));
            MediaInfo info = new MediaInfo.Builder(url)
                    .setStreamType(contentType.toLowerCase().contains("live") ? MediaInfo.STREAM_TYPE_LIVE : MediaInfo.STREAM_TYPE_BUFFERED)
                    .setContentType(value(mimeType, "application/x-mpegURL"))
                    .setMetadata(md)
                    .build();
            client.load(new MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).setCurrentTime(player == null ? 0 : Math.max(0,player.getCurrentPosition())).build());
            if (player != null) player.pause();
            Toast.makeText(this,"Diffusion vers le téléviseur",Toast.LENGTH_SHORT).show();
        } catch (Throwable error) { report("CAST_LOAD_FAILED", error); }
    }

    private void report(String code, Throwable error) {
        lastDiagnostic = buildDiagnostic(code,error);
        saveDiagnostic(lastDiagnostic);
        Toast.makeText(this,"Erreur détectée. Diagnostic enregistré dans Téléchargements.",Toast.LENGTH_LONG).show();
    }

    private String buildDiagnostic(String code, Throwable error) {
        StringBuilder out = new StringBuilder();
        out.append("STREAMBOX NATIVE DIAGNOSTIC\n");
        out.append("Date: ").append(new Date()).append("\n");
        out.append("Code: ").append(code).append("\n");
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" API ").append(Build.VERSION.SDK_INT).append("\n");
        out.append("Device: ").append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("\n");
        out.append("Network: ").append(networkType()).append("\n");
        out.append("Title: ").append(title).append("\n");
        out.append("ContentType: ").append(contentType).append("\n");
        out.append("Mime: ").append(mimeType).append("\n");
        out.append("URL: ").append(mask(url)).append("\n");
        if (player != null) {
            out.append("PlayerState: ").append(player.getPlaybackState()).append("\n");
            out.append("Position: ").append(player.getCurrentPosition()).append("\n");
            out.append("Buffered: ").append(player.getBufferedPosition()).append("\n");
        }
        if (error != null) {
            Throwable t=error; int depth=0;
            while(t!=null && depth<12){ out.append("Cause[").append(depth).append("]: ").append(t.getClass().getName()).append(": ").append(t.getMessage()).append("\n"); t=t.getCause(); depth++; }
        }
        return out.toString();
    }

    private void saveDiagnostic(String text) {
        try {
            String name="streambox-diagnostic-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date())+".txt";
            ContentResolver resolver=getContentResolver();
            ContentValues values=new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
            values.put(MediaStore.MediaColumns.MIME_TYPE,"text/plain");
            if(Build.VERSION.SDK_INT>=29) values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/StreamBoxDiagnostics");
            Uri uri=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null) throw new IllegalStateException("MediaStore insert null");
            try(OutputStream os=resolver.openOutputStream(uri)){ if(os==null) throw new IllegalStateException("OutputStream null"); os.write(text.getBytes(StandardCharsets.UTF_8)); }
        } catch(Throwable error) {
            Intent share=new Intent(Intent.ACTION_SEND); share.setType("text/plain"); share.putExtra(Intent.EXTRA_TEXT,text); startActivity(Intent.createChooser(share,"Partager le diagnostic"));
        }
    }

    private String networkType(){
        try { ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE); NetworkCapabilities nc=cm.getNetworkCapabilities(cm.getActiveNetwork()); if(nc==null)return "offline"; if(nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI))return "wifi"; if(nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR))return "mobile"; if(nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET))return "ethernet"; return "other"; } catch(Throwable e){ return "unknown"; }
    }
    private static String inferMime(String u){ if(u==null)return null; String x=u.toLowerCase(Locale.US); if(x.contains(".m3u8"))return MimeTypes.APPLICATION_M3U8; if(x.contains(".mpd"))return MimeTypes.APPLICATION_MPD; if(x.contains(".mp4"))return MimeTypes.VIDEO_MP4; if(x.contains(".webm"))return MimeTypes.VIDEO_WEBM; if(x.contains(".ts"))return MimeTypes.VIDEO_MP2T; return null; }
    private static String value(String v,String d){ return v==null||v.trim().isEmpty()?d:v; }
    private static String mask(String u){ if(u==null)return ""; return u.replaceAll("/(live|movie|series)/[^/]+/[^/]+/","/$1/***/***/").replaceAll("([?&](username|password)=)[^&]+","$1***"); }

    @Override public void onUserLeaveHint(){ super.onUserLeaveHint(); if(Build.VERSION.SDK_INT>=26 && player!=null && player.isPlaying()) enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(16,9)).build()); }
    @Override public void onPictureInPictureModeChanged(boolean inPip, Configuration config){ super.onPictureInPictureModeChanged(inPip,config); }
    @Override protected void onStop(){ super.onStop(); if(!isInPictureInPictureMode()) releasePlayer(); }
    @Override protected void onDestroy(){ if(castContext!=null) castContext.getSessionManager().removeSessionManagerListener(castListener,CastSession.class); releasePlayer(); super.onDestroy(); }
    private void releasePlayer(){ if(player!=null){ player.release(); player=null; } }
}