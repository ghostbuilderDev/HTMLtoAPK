const VERSION="forgeapk-v16";
self.addEventListener("install",event=>{
  event.waitUntil(caches.keys()
    .then(keys=>Promise.all(keys.map(key=>caches.delete(key))))
    .then(()=>self.skipWaiting()));
});
self.addEventListener("activate",event=>{
  event.waitUntil(self.registration.unregister()
    .then(()=>self.clients.claim()));
});
