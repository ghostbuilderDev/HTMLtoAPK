FORGEAPK STUDIO V16 — CORRECTION

Le rapport transmis montre une compilation réussie, mais réalisée avec
l’ancienne v14 :
- assembleDebug ;
- nom Mon application ;
- APK se terminant par -debug.apk ;
- fichiers CORRECTION-V14.txt et README-AUTO-CONVERSION.txt.

La v16 corrige :
- cache et Service Worker anciens ;
- ancienne configuration Mon application ;
- origine WebView versionnée ;
- purge native à chaque mise à jour ;
- auto-conversion en un bouton ;
- rejet des anciens dossiers ForgeAPK ;
- compilation exclusivement release.

UTILISATION
1. Ouvre forgeapk-studio-v16-anti-cache.html.
2. Appuie sur « Préparer automatiquement ForgeAPK Studio v16 ».
3. Lance « Générer et enregistrer l’APK sur ce téléphone ».
4. Installe uniquement le fichier se terminant par -release.apk.
