window.ApkBuilderRuntime = {
  isAndroidApk() {
    return typeof window.AndroidApp !== "undefined";
  },
  start(title, message) {
    try {
      window.AndroidApp?.startBackgroundTask?.(String(title), String(message));
    } catch (error) {}
  },
  update(message) {
    try {
      window.AndroidApp?.updateBackgroundTask?.(String(message));
    } catch (error) {}
  },
  finish(message, success = true) {
    try {
      window.AndroidApp?.finishBackgroundTask?.(String(message), Boolean(success));
    } catch (error) {}
  }
};
