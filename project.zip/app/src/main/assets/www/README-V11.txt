STREAMBOX VISION V11 — CORRECTION DIAGNOSTIC + IDENTIFIANTS PERSISTANTS

IMPORTANT
La lecture Media3 et le véritable Google Cast sont disponibles uniquement dans android-native-project.
Le ZIP HTMLtoAPK reste une version WebView de secours. Une WebView seule ne peut pas intégrer Media3/Google Cast.

CORRECTIONS V11
- Diagnostic exporté par le pont Android natif quand il existe.
- Secours sans pont : partage Android via Web Share, téléchargement Blob, puis copie presse-papiers.
- Plus de dépendance obligatoire à un pont d'enregistrement inconnu.
- Serveur, identifiant et mot de passe sauvegardés en localStorage et dans SharedPreferences natif.
- Migration automatique des profils des versions 4 à 10.
- Préremplissage de la page de connexion.
- Connexion automatique au démarrage.
- Le catalogue complet n'est toujours pas conservé en localStorage.
- Cache Service Worker V11 remplacé pour éviter le chargement d'un ancien JavaScript.

MISE À JOUR
Pour conserver les identifiants, installe le nouvel APK PAR-DESSUS l'ancien avec le même package et la même signature.
Ne désinstalle pas l'application avant la mise à jour : Android efface normalement les données d'une application désinstallée.

VERSION NATIVE
Importer android-native-project à la racine d'un dépôt GitHub, puis lancer Actions > Build StreamBox APK.
Cette version utilise PlayerActivity/Media3 et le SDK Google Cast natif.
