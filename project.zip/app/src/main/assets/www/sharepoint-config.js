/*
  Configuration côté navigateur.
  IMPORTANT : ne jamais mettre de secret Microsoft ici.
  Les secrets Microsoft restent dans les variables d'environnement de Supabase Edge Functions.
*/
window.SHAREPOINT_EXPORT_CONFIG = {
  enabled: true,

  // Remplacer par l'URL réelle après déploiement Supabase :
  // https://<PROJECT_REF>.supabase.co/functions/v1/upload-sharepoint
  supabaseFunctionUrl: 'https://VOTRE_PROJECT_REF.supabase.co/functions/v1/upload-sharepoint',

  // Clé anon/publishable Supabase. Elle peut être publique.
  // Exemple : sb_publishable_xxx ou ancienne clé anon JWT selon votre projet.
  supabaseAnonKey: 'VOTRE_CLE_SUPABASE_ANON_OU_PUBLISHABLE',

  // Chantier par défaut si aucune correspondance n'est trouvée.
  defaultChantierKey: 'default',

  // Permet d'associer le texte saisi dans "Chantier / opération" à une clé de routage.
  // La clé de routage doit exister aussi dans SHAREPOINT_ROUTES_JSON côté Supabase.
  chantierAliases: {
    'AINM - MONTEREAU': 'ainm-montereau',
    'ainm_montereau': 'ainm-montereau',
    'ainm-montereau': 'ainm-montereau',
    'SAMOIS': 'samois',
    'samois': 'samois',
    'GARENNE': 'garenne',
    'garenne': 'garenne'
  }
};
