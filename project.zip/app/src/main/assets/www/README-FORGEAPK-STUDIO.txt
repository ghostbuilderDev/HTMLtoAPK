FORGEAPK STUDIO V15 — PAQUET AUTONOME

Nom : ForgeAPK Studio
Package conseillé : dev.ghostbuilder.forgeapkstudio

NOUVEAUTÉS
- Sélection Android de plusieurs fichiers via ClipData.
- Import ZIP complet avec conservation des sous-dossiers.
- Détection automatique de index.html.
- APK release signé et non débogable.
- WebView sur origine HTTPS locale, file:// désactivé.
- Safe Browsing, cookies tiers bloqués, sauvegarde Android désactivée.
- Analyse de sécurité HTML/JS.
- Chronomètre, arrière-plan, reprise et diagnostic permanent.

CRÉER L’APK DE FORGEAPK STUDIO
1. Ouvre forgeapk-studio-v15.html.
2. Sélectionne ce ZIP dans « ZIP du site complet » ou le dossier extrait.
3. Nom : ForgeAPK Studio.
4. Package : dev.ghostbuilder.forgeapkstudio.
5. Internet et vibration : oui. Caméra, micro, localisation et HTTP : non.
6. Icône : icons/forgeapk-512.png.
7. Lance la génération directe.
