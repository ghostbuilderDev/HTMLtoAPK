MISE À JOUR DIRECTE DE HTMLtoAPK — IPTV NATIVE 2.1

Ce ZIP est prévu pour être importé directement dans l'application HTMLtoAPK déjà installée.

RÉGLAGES À UTILISER DANS HTMLtoAPK

Nom affiché : HTMLtoAPK IPTV Native
Identifiant Android : com.yoann.monapplication
Version : 2.1.0
Code version : 206500001 (ou toute valeur supérieure à la version déjà installée)
Fichier principal : index.html (détecté automatiquement)
Orientation : automatique
Internet : activé
Stockage DOM : activé
Accès aux fichiers : activé
Liens externes : activé
Téléchargements Android : activé
HTTP non chiffré : activé
Contenu mixte : ALWAYS_ALLOW

IMPORTANT POUR UNE VRAIE MISE À JOUR
- Utiliser exactement le même identifiant Android que l'application HTMLtoAPK installée.
- Compiler depuis le même dépôt GitHub afin de conserver la même clé de signature.
- Installer le nouvel APK par-dessus l'ancien, sans désinstaller.
- Si Android refuse l'installation, vérifier que la signature du dépôt est identique.

CE QUE CETTE VERSION AJOUTE AU GÉNÉRATEUR
- Option Mode IPTV natif + Google Cast.
- Génération automatique d'un lecteur Media3 ExoPlayer.
- Lecture Live TV, films et séries.
- Google Cast natif et découverte des téléviseurs compatibles.
- Diagnostic Android natif.
- Stockage sécurisé des profils et identifiants.
- Ponts AndroidApp.playNative, castNative, saveDiagnostic, saveSecret et loadSecret.

UTILISATION ENSUITE POUR STREAMBOX
1. Installer cette mise à jour de HTMLtoAPK.
2. Ouvrir la nouvelle application.
3. Importer le ZIP StreamBox.
4. Cocher « Mode IPTV natif + Google Cast ».
5. Générer l'APK depuis le dépôt GitHub habituel.
