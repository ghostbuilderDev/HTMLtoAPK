# Briefing chantier — Export SharePoint

Cette version ajoute un bouton **Exporter vers SharePoint** dans le menu **Actions** de l'application HTML.

Le principe est le suivant :

1. L'application HTML génère le briefing.
2. Elle envoie le fichier HTML à une **Supabase Edge Function**.
3. La fonction Supabase utilise **Microsoft Graph** pour déposer le fichier dans le dossier SharePoint correspondant au chantier.

Les secrets Microsoft ne sont jamais placés dans le HTML.

## Fichiers principaux

- `public/index.html` : application HTML complète.
- `public/sharepoint-config.js` : configuration publique côté navigateur.
- `supabase/functions/upload-sharepoint/index.ts` : fonction serveur qui envoie vers SharePoint.
- `.env.example` : modèle des variables d'environnement à déclarer dans Supabase.
- `supabase/sql/001_export_logs.sql` : table optionnelle de journalisation.

## Configuration côté application

Modifier `public/sharepoint-config.js` :

```js
window.SHAREPOINT_EXPORT_CONFIG = {
  enabled: true,
  supabaseFunctionUrl: 'https://VOTRE_PROJECT_REF.supabase.co/functions/v1/upload-sharepoint',
  supabaseAnonKey: 'VOTRE_CLE_SUPABASE_ANON_OU_PUBLISHABLE',
  defaultChantierKey: 'default',
  chantierAliases: {
    'AINM - MONTEREAU': 'ainm-montereau'
  }
};
```

## Configuration Supabase

Dans Supabase, créer les secrets de la fonction :

```bash
supabase secrets set MS_TENANT_ID="..."
supabase secrets set MS_CLIENT_ID="..."
supabase secrets set MS_CLIENT_SECRET="..."
supabase secrets set SHAREPOINT_ROUTES_JSON='{"default":{"driveId":"...","folderPath":"Briefings/Autres"},"ainm-montereau":{"driveId":"...","folderPath":"Chantiers/AINM-MONTEREAU/Briefings"}}'
```

Déployer la fonction :

```bash
supabase functions deploy upload-sharepoint
```

## Configuration Microsoft Azure / Entra ID

Créer une application dans Microsoft Entra ID, puis donner les permissions Microsoft Graph nécessaires à l'écriture dans SharePoint. Pour l'upload simple, Microsoft Graph permet de créer ou remplacer un fichier via `PUT /drives/{drive-id}/root:/{path}:/content` jusqu'à 250 Mo. Pour des fichiers plus gros, il faut utiliser une session d'upload. Voir la documentation officielle Microsoft Graph.

Le flux recommandé ici est le **client credentials flow**, car l'upload est réalisé côté serveur par la fonction Supabase, sans exposer le secret Microsoft côté navigateur.

## Déploiement GitHub

Mettre le contenu de ce dossier dans un dépôt GitHub. Pour GitHub Pages, publier le dossier `public/` ou utiliser le fichier `index.html` à la racine.

## Remarque importante

Le bouton SharePoint fonctionne uniquement lorsque :

- `public/sharepoint-config.js` contient la bonne URL Supabase ;
- la fonction `upload-sharepoint` est déployée ;
- les secrets Microsoft et `SHAREPOINT_ROUTES_JSON` sont configurés ;
- l'application Microsoft a les droits nécessaires sur le SharePoint cible.
