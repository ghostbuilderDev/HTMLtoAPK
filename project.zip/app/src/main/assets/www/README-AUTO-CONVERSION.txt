HTML → APK BUILDER — VERSION STABLE V14

CAUSE DE LA PANNE V13
La v13 utilisait PATCH /git/ref/heads/main.
GitHub exige /git/refs/heads/main pour une mise à jour.
La requête retournait 404 et le commit restait détaché.

SOLUTION V14
La mécanique Git bas niveau est supprimée du parcours principal.
La v14 utilise l’API Contents :
1. publication du workflow ;
2. récupération du SHA du commit workflow ;
3. attente de l’indexation du workflow ;
4. publication de project.zip ;
5. récupération du SHA du commit projet ;
6. recherche ou déclenchement du run ;
7. association obligatoire du run au SHA du projet ;
8. récupération du seul APK correspondant.

CRÉER L’APK DU GÉNÉRATEUR
1. Extraire cette archive.
2. Ouvrir html-apk-builder-v14-stable.html.
3. Sélectionner le dossier extrait.
4. Nom : HTML APK Builder.
5. Identifiant : dev.ghostbuilder.htmlapkbuilder.
6. Activer Internet, vibration et liens externes.
7. Lancer la génération directe.

RÉGLAGE ANDROID
Paramètres > Applications > HTML APK Builder >
Batterie > Sans restriction.
