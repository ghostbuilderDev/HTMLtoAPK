HTML → APK BUILDER — PAQUET AUTONOME V12

POUR CRÉER L'APK DU GÉNÉRATEUR
1. Extrais ce ZIP dans un dossier.
2. Ouvre html-apk-builder-v12-background-timer.html.
3. Dans « Dossier complet du site », sélectionne le dossier extrait.
4. index.html sera détecté automatiquement.
5. Nom conseillé : HTML APK Builder.
6. Identifiant conseillé : dev.ghostbuilder.htmlapkbuilder.
7. Active Internet et Vibration.
8. Lance « Générer et enregistrer l’APK sur ce téléphone ».

FONCTIONNEMENT EN ARRIÈRE-PLAN
- L’APK utilise un service Android au premier plan avec notification persistante.
- GitHub continue la compilation même si Android suspend l’interface.
- Le run GitHub est mémorisé localement.
- À la réouverture, le suivi reprend et l’APK est récupéré.
- Le jeton GitHub n’est jamais enregistré : après un arrêt complet du processus,
  il faudra le renseigner de nouveau.

RÉGLAGE ANDROID CONSEILLÉ
Paramètres > Applications > HTML APK Builder > Batterie > Sans restriction.

FICHIERS
- index.html : application complète.
- manifest.webmanifest : mode PWA.
- sw.js : cache hors ligne en HTTPS.
- icons/ : icônes.
- android-runtime.js : pont Android documenté.
- CONFIGURATION-APK.txt : paramètres recommandés.
