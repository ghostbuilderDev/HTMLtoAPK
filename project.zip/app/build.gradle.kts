plugins {
    id("com.android.application")
}

val stableKeystore = rootProject.file(".signing/html-apk-stable.p12")
val stableStorePassword = "HTML_APK_BUILDER_STABLE_2026"
val stableKeyAlias = "html-apk-stable"
val stableKeyPassword = "HTML_APK_BUILDER_STABLE_2026"

android {
    namespace = "dev.ghostbuilderdev.htmltoapk.monapplication.a1rsolc8"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.ghostbuilderdev.htmltoapk.monapplication.a1rsolc8"
        minSdk = 24
        targetSdk = 35
        versionCode = 206444821
        versionName = "1.0.1"
    }

    signingConfigs {
        create("stable") {
            if (stableKeystore.exists()) {
                storeFile = stableKeystore
                storePassword = stableStorePassword
                keyAlias = stableKeyAlias
                keyPassword = stableKeyPassword
                storeType = "PKCS12"
            }
        }
    }

    buildTypes {
        debug {
            if (stableKeystore.exists()) {
                signingConfig = signingConfigs.getByName("stable")
            }
        }

        release {
            isMinifyEnabled = false
            if (stableKeystore.exists()) {
                signingConfig = signingConfigs.getByName("stable")
            }
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
